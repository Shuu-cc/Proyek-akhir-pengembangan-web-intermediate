import { loginUser } from '../../data/api.js';

class LoginPresenter {
  constructor({ view }) {
    this._view = view;
  }

  async login({ email, password }) {
    try {
      const result = await loginUser({ email, password });
      this._view.onLoginSuccess(result.loginResult);
    } catch (err) {
      this._view.showMessage(err.message, true);
    }
  }
}

export default LoginPresenter;
