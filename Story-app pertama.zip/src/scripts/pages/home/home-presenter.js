class HomePresenter {
  constructor({ view, model }) {
    this._view = view;
    this._model = model;
  }

  async init() {
    try {
      const stories = await this._model.getStories({page: 1, size: 20, location: 1});
      this._view.showStories(stories);
      this._view.showMap(stories);
    } catch (error) {
      this._view.showError('Gagal mengambil data cerita.');
    }
  }
}

export default HomePresenter;