import HomePresenter from './home-presenter.js';
import { getStories } from '../../data/api.js';
import MapView from '../../components/map/map-view.js';

class HomePage {
  async render() {
    return `
      <section class="home">
        <h2>Daftar Cerita</h2>
        <ul id="story-list"></ul>
        <div id="map" style="height: 500px; margin-top: 20px;"></div>
      </section>
    `;
  }


  async afterRender() {
    const token = localStorage.getItem('token');
    const storyListContainer = document.querySelector('#story-list');
    const mapContainer = document.querySelector('#map');

    
    if (!token) {
      storyListContainer.innerHTML = `<p class="error">Anda belum login. Mengarahkan ke halaman login...</p>`;
      setTimeout(() => {
        window.location.hash = '#/login';
      }, 1000);
      return;
    }

    const presenter = new HomePresenter({
      view: {
        showStories(stories) {
           storyListContainer.innerHTML = '';

           if (!stories || stories.length === 0) {
            storyListContainer.innerHTML = '<p>Tidak ada cerita ditemukan.</p>';
            return;
          }

          stories.forEach((story) => {
            const li = document.createElement('li');
            li.innerHTML = `
              <div class="story-image-container">
              <img src="${story.photoUrl}" alt="Foto dari cerita oleh${story.name}" width="100">
              </div>
              <div class="story-content">
              <p><strong>Nama:</strong> ${story.name}</p>
              <p><strong>Deskripsi:</strong> ${story.description}</p>
              <p><strong>Tanggal:</strong> ${new Date(story.createdAt).toLocaleDateString()}</p>
              </div>
            `;
             storyListContainer.appendChild(li);
          });
          },

          showMap(stories) {
          MapView.render(mapContainer, stories); 
        },

          showError(message) {
          storyListContainer.innerHTML = `<p class="error">${message}</p>`;
        },
      },
      
      model: {
        async getStories() {
          return await getStories({ page: 1, size: 20, location: 1 });
        },
      },
    });

    await presenter.init();
  }
}


export default HomePage;
