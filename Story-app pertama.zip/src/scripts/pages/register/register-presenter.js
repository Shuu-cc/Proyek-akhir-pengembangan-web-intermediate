import { registerUser } from '../../data/api.js';

class RegisterPresenter {
  constructor({ view }) {
    this._view = view;
  }

  async register({ name, email, password }) {
    try {
      const result = await registerUser({ name, email, password });
      this._view.showMessage(result.message);
    } catch (error) {
      this._view.showMessage(error.message, true);
    }
  }
}

export default RegisterPresenter;
