import { addNewStory } from '../../data/api.js';

class AddPresenter {
  constructor({ onSubmit }) {
    this.onSubmit = onSubmit;
  }

  async add(payload) {
    return await addNewStory(payload);
  }
}

export default AddPresenter;
