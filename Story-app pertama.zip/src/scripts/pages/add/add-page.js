import { addNewStory } from '../../data/api.js';
import SelectLocationMap from '../../components/map/select-location-map.js';

class AddPage {
  async render() {
    return `
      <section class="add">
        <h2>Tambah Cerita</h2>
        <button id="back-home" style="margin-bottom: 10px;">⬅ Kembali ke Beranda</button>

        <form id="add-form" enctype="multipart/form-data">

          <label for="description">Deskripsi</label>
          <textarea id="description" placeholder="Deskripsi cerita..." required></textarea>

          <label for="photo">Unggah Foto</label>
          <input type="file" id="photo" accept="image/*" />

          <small>Pilih file dari galeri atau gunakan kamera di bawah.</small>

          <button type="button" id="start-camera" style="background:goldenrod;color:white;margin-top:5px;">Aktifkan Kamera</button>
          <video id="camera" autoplay playsinline width="300" style="display:none;margin-top:10px;"></video>

          <button type="button" id="capture" style="display:none;margin-top:5px;">📸 Ambil Gambar</button>
          <canvas id="preview" width="300" style="display:none;"></canvas>

          <label for="latitude">Latitude (opsional)</label>
          <input type="text" id="latitude" readonly />

          <label for="longitude">Longitude (opsional)</label>
          <input type="text" id="longitude" readonly />

          <div id="map" style="height: 300px; margin-top: 10px;"></div>

          <button type="submit" style="background:#007bff;color:white;margin-top:10px;">Tambah Story</button>
        </form>
        <div id="message" style="margin-top: 10px;"></div>
      </section>
    `;
  }

  async afterRender() {
    const form = document.querySelector('#add-form');
    const message = document.querySelector('#message');
    const description = document.querySelector('#description');
    const fileInput = document.querySelector('#photo');
    const latitude = document.querySelector('#latitude');
    const longitude = document.querySelector('#longitude');
    const mapContainer = document.querySelector('#map');

    const cameraBtn = document.querySelector('#start-camera');
    const video = document.querySelector('#camera');
    const captureBtn = document.querySelector('#capture');
    const canvas = document.querySelector('#preview');

    let photoBlob = null;
    let stream = null;


    cameraBtn.addEventListener('click', async () => {
      stream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = stream;
      video.style.display = 'block';
      captureBtn.style.display = 'inline-block';
    });

    captureBtn.addEventListener('click', () => {
      canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        photoBlob = blob;
        fileInput.value = ''; 
      }, 'image/jpeg');
      canvas.style.display = 'block';
    });

    
    SelectLocationMap.render(mapContainer, (lat, lon) => {
      latitude.value = lat.toFixed(6);
      longitude.value = lon.toFixed(6);
    });

    
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const token = localStorage.getItem('token');
      if (!token) {
        message.innerText = '❌ Anda harus login terlebih dahulu.';
        return;
      }

      const desc = description.value.trim();
      const lat = latitude.value || null;
      const lon = longitude.value || null;

      const photoFile = fileInput.files[0];
      const finalPhoto = photoBlob || photoFile;

      if (!desc || !finalPhoto) {
        message.innerText = '❗ Deskripsi dan foto wajib diisi!';
        return;
      }

      try {
        const formData = new FormData();
        formData.append('description', desc);
        formData.append('photo', finalPhoto);
        if (lat) formData.append('lat', lat);
        if (lon) formData.append('lon', lon);

        const response = await fetch(`https://story-api.dicoding.dev/v1/stories`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        });

        const data = await response.json();
        if (!response.ok || data.error) throw new Error(data.message);
        message.innerHTML = '✅ Story berhasil ditambahkan!';
        setTimeout(() => window.location.hash = '#/', 1500);
      } catch (err) {
        message.innerHTML = `❌ ${err.message}`;
      } finally {
        if (stream) stream.getTracks().forEach((t) => t.stop());
      }
    });

    document.querySelector('#back-home').addEventListener('click', () => {
    window.location.hash = '#/';
});

  }
}

export default AddPage;
