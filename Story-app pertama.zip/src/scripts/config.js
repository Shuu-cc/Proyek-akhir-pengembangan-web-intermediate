const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  API_TOKEN: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyLWhJSmZ1RnZGUXhXakZxWk0iLCJpYXQiOjE3NDczODQzODV9.x-333NjP074GNXIAoF4tkamJZqY2meMHdbn2c8tSaMY',
};

export default CONFIG;
